﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLibrary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.dgvLibrary = New System.Windows.Forms.DataGridView()
        Me.IntGameIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrConsoleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrFormatDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrGenreDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrLengthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtmDateAddedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtmDateFinishedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VLibraryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbLibraryManagerDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbLibraryManagerDataSet = New Game_Library_Manager.dbLibraryManagerDataSet()
        Me.VLibraryTableAdapter = New Game_Library_Manager.dbLibraryManagerDataSetTableAdapters.vLibraryTableAdapter()
        CType(Me.dgvLibrary, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VLibraryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbLibraryManagerDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbLibraryManagerDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvLibrary
        '
        Me.dgvLibrary.AllowUserToAddRows = False
        Me.dgvLibrary.AllowUserToDeleteRows = False
        Me.dgvLibrary.AllowUserToResizeColumns = False
        Me.dgvLibrary.AllowUserToResizeRows = False
        Me.dgvLibrary.AutoGenerateColumns = False
        Me.dgvLibrary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLibrary.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntGameIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.StrStatusDataGridViewTextBoxColumn, Me.StrConsoleDataGridViewTextBoxColumn, Me.StrFormatDataGridViewTextBoxColumn, Me.StrGenreDataGridViewTextBoxColumn, Me.StrLengthDataGridViewTextBoxColumn, Me.DtmDateAddedDataGridViewTextBoxColumn, Me.DtmDateFinishedDataGridViewTextBoxColumn})
        Me.dgvLibrary.DataSource = Me.VLibraryBindingSource
        Me.dgvLibrary.Location = New System.Drawing.Point(12, 12)
        Me.dgvLibrary.Name = "dgvLibrary"
        Me.dgvLibrary.ReadOnly = True
        Me.dgvLibrary.Size = New System.Drawing.Size(925, 426)
        Me.dgvLibrary.TabIndex = 0
        '
        'IntGameIDDataGridViewTextBoxColumn
        '
        Me.IntGameIDDataGridViewTextBoxColumn.DataPropertyName = "intGameID"
        Me.IntGameIDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IntGameIDDataGridViewTextBoxColumn.Name = "IntGameIDDataGridViewTextBoxColumn"
        Me.IntGameIDDataGridViewTextBoxColumn.Width = 40
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.Width = 200
        '
        'StrStatusDataGridViewTextBoxColumn
        '
        Me.StrStatusDataGridViewTextBoxColumn.DataPropertyName = "strStatus"
        Me.StrStatusDataGridViewTextBoxColumn.HeaderText = "strStatus"
        Me.StrStatusDataGridViewTextBoxColumn.Name = "StrStatusDataGridViewTextBoxColumn"
        '
        'StrConsoleDataGridViewTextBoxColumn
        '
        Me.StrConsoleDataGridViewTextBoxColumn.DataPropertyName = "strConsole"
        Me.StrConsoleDataGridViewTextBoxColumn.HeaderText = "strConsole"
        Me.StrConsoleDataGridViewTextBoxColumn.Name = "StrConsoleDataGridViewTextBoxColumn"
        '
        'StrFormatDataGridViewTextBoxColumn
        '
        Me.StrFormatDataGridViewTextBoxColumn.DataPropertyName = "strFormat"
        Me.StrFormatDataGridViewTextBoxColumn.HeaderText = "strFormat"
        Me.StrFormatDataGridViewTextBoxColumn.Name = "StrFormatDataGridViewTextBoxColumn"
        Me.StrFormatDataGridViewTextBoxColumn.Width = 70
        '
        'StrGenreDataGridViewTextBoxColumn
        '
        Me.StrGenreDataGridViewTextBoxColumn.DataPropertyName = "strGenre"
        Me.StrGenreDataGridViewTextBoxColumn.HeaderText = "strGenre"
        Me.StrGenreDataGridViewTextBoxColumn.Name = "StrGenreDataGridViewTextBoxColumn"
        '
        'StrLengthDataGridViewTextBoxColumn
        '
        Me.StrLengthDataGridViewTextBoxColumn.DataPropertyName = "strLength"
        Me.StrLengthDataGridViewTextBoxColumn.HeaderText = "strLength"
        Me.StrLengthDataGridViewTextBoxColumn.Name = "StrLengthDataGridViewTextBoxColumn"
        Me.StrLengthDataGridViewTextBoxColumn.Width = 70
        '
        'DtmDateAddedDataGridViewTextBoxColumn
        '
        Me.DtmDateAddedDataGridViewTextBoxColumn.DataPropertyName = "dtmDateAdded"
        Me.DtmDateAddedDataGridViewTextBoxColumn.HeaderText = "dtmDateAdded"
        Me.DtmDateAddedDataGridViewTextBoxColumn.Name = "DtmDateAddedDataGridViewTextBoxColumn"
        '
        'DtmDateFinishedDataGridViewTextBoxColumn
        '
        Me.DtmDateFinishedDataGridViewTextBoxColumn.DataPropertyName = "dtmDateFinished"
        Me.DtmDateFinishedDataGridViewTextBoxColumn.HeaderText = "dtmDateFinished"
        Me.DtmDateFinishedDataGridViewTextBoxColumn.Name = "DtmDateFinishedDataGridViewTextBoxColumn"
        '
        'VLibraryBindingSource
        '
        Me.VLibraryBindingSource.DataMember = "vLibrary"
        Me.VLibraryBindingSource.DataSource = Me.DbLibraryManagerDataSetBindingSource
        '
        'DbLibraryManagerDataSetBindingSource
        '
        Me.DbLibraryManagerDataSetBindingSource.DataSource = Me.DbLibraryManagerDataSet
        Me.DbLibraryManagerDataSetBindingSource.Position = 0
        '
        'DbLibraryManagerDataSet
        '
        Me.DbLibraryManagerDataSet.DataSetName = "dbLibraryManagerDataSet"
        Me.DbLibraryManagerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VLibraryTableAdapter
        '
        Me.VLibraryTableAdapter.ClearBeforeFill = True
        '
        'frmLibrary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(948, 450)
        Me.Controls.Add(Me.dgvLibrary)
        Me.Name = "frmLibrary"
        Me.Text = "Library"
        CType(Me.dgvLibrary, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VLibraryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbLibraryManagerDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbLibraryManagerDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvLibrary As DataGridView
    Friend WithEvents DbLibraryManagerDataSetBindingSource As BindingSource
    Friend WithEvents DbLibraryManagerDataSet As dbLibraryManagerDataSet
    Friend WithEvents VLibraryBindingSource As BindingSource
    Friend WithEvents VLibraryTableAdapter As dbLibraryManagerDataSetTableAdapters.vLibraryTableAdapter
    Friend WithEvents IntGameIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrConsoleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrFormatDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrGenreDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrLengthDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DtmDateAddedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DtmDateFinishedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
