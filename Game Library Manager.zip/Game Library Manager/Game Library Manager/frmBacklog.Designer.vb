﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBacklog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.dgvBacklog = New System.Windows.Forms.DataGridView()
        Me.IntGameIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrConsoleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrFormatDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrGenreDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrLengthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtmDateAddedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VBacklogBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbLibraryManagerDataSet1 = New Game_Library_Manager.dbLibraryManagerDataSet1()
        Me.VBacklogTableAdapter = New Game_Library_Manager.dbLibraryManagerDataSet1TableAdapters.vBacklogTableAdapter()
        Me.btnSurpriseMe = New System.Windows.Forms.Button()
        Me.btnFinish = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        CType(Me.dgvBacklog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VBacklogBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbLibraryManagerDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvBacklog
        '
        Me.dgvBacklog.AllowUserToAddRows = False
        Me.dgvBacklog.AllowUserToDeleteRows = False
        Me.dgvBacklog.AllowUserToResizeColumns = False
        Me.dgvBacklog.AllowUserToResizeRows = False
        Me.dgvBacklog.AutoGenerateColumns = False
        Me.dgvBacklog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBacklog.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntGameIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.StrStatusDataGridViewTextBoxColumn, Me.StrConsoleDataGridViewTextBoxColumn, Me.StrFormatDataGridViewTextBoxColumn, Me.StrGenreDataGridViewTextBoxColumn, Me.StrLengthDataGridViewTextBoxColumn, Me.DtmDateAddedDataGridViewTextBoxColumn})
        Me.dgvBacklog.DataSource = Me.VBacklogBindingSource
        Me.dgvBacklog.Location = New System.Drawing.Point(29, 12)
        Me.dgvBacklog.MultiSelect = False
        Me.dgvBacklog.Name = "dgvBacklog"
        Me.dgvBacklog.ReadOnly = True
        Me.dgvBacklog.Size = New System.Drawing.Size(845, 426)
        Me.dgvBacklog.TabIndex = 1
        '
        'IntGameIDDataGridViewTextBoxColumn
        '
        Me.IntGameIDDataGridViewTextBoxColumn.DataPropertyName = "intGameID"
        Me.IntGameIDDataGridViewTextBoxColumn.HeaderText = "intGameID"
        Me.IntGameIDDataGridViewTextBoxColumn.Name = "IntGameIDDataGridViewTextBoxColumn"
        Me.IntGameIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrStatusDataGridViewTextBoxColumn
        '
        Me.StrStatusDataGridViewTextBoxColumn.DataPropertyName = "strStatus"
        Me.StrStatusDataGridViewTextBoxColumn.HeaderText = "strStatus"
        Me.StrStatusDataGridViewTextBoxColumn.Name = "StrStatusDataGridViewTextBoxColumn"
        Me.StrStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrConsoleDataGridViewTextBoxColumn
        '
        Me.StrConsoleDataGridViewTextBoxColumn.DataPropertyName = "strConsole"
        Me.StrConsoleDataGridViewTextBoxColumn.HeaderText = "strConsole"
        Me.StrConsoleDataGridViewTextBoxColumn.Name = "StrConsoleDataGridViewTextBoxColumn"
        Me.StrConsoleDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrFormatDataGridViewTextBoxColumn
        '
        Me.StrFormatDataGridViewTextBoxColumn.DataPropertyName = "strFormat"
        Me.StrFormatDataGridViewTextBoxColumn.HeaderText = "strFormat"
        Me.StrFormatDataGridViewTextBoxColumn.Name = "StrFormatDataGridViewTextBoxColumn"
        Me.StrFormatDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrGenreDataGridViewTextBoxColumn
        '
        Me.StrGenreDataGridViewTextBoxColumn.DataPropertyName = "strGenre"
        Me.StrGenreDataGridViewTextBoxColumn.HeaderText = "strGenre"
        Me.StrGenreDataGridViewTextBoxColumn.Name = "StrGenreDataGridViewTextBoxColumn"
        Me.StrGenreDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrLengthDataGridViewTextBoxColumn
        '
        Me.StrLengthDataGridViewTextBoxColumn.DataPropertyName = "strLength"
        Me.StrLengthDataGridViewTextBoxColumn.HeaderText = "strLength"
        Me.StrLengthDataGridViewTextBoxColumn.Name = "StrLengthDataGridViewTextBoxColumn"
        Me.StrLengthDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DtmDateAddedDataGridViewTextBoxColumn
        '
        Me.DtmDateAddedDataGridViewTextBoxColumn.DataPropertyName = "dtmDateAdded"
        Me.DtmDateAddedDataGridViewTextBoxColumn.HeaderText = "dtmDateAdded"
        Me.DtmDateAddedDataGridViewTextBoxColumn.Name = "DtmDateAddedDataGridViewTextBoxColumn"
        Me.DtmDateAddedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VBacklogBindingSource
        '
        Me.VBacklogBindingSource.DataMember = "vBacklog"
        Me.VBacklogBindingSource.DataSource = Me.DbLibraryManagerDataSet1
        '
        'DbLibraryManagerDataSet1
        '
        Me.DbLibraryManagerDataSet1.DataSetName = "dbLibraryManagerDataSet1"
        Me.DbLibraryManagerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VBacklogTableAdapter
        '
        Me.VBacklogTableAdapter.ClearBeforeFill = True
        '
        'btnSurpriseMe
        '
        Me.btnSurpriseMe.Location = New System.Drawing.Point(901, 169)
        Me.btnSurpriseMe.Name = "btnSurpriseMe"
        Me.btnSurpriseMe.Size = New System.Drawing.Size(138, 80)
        Me.btnSurpriseMe.TabIndex = 2
        Me.btnSurpriseMe.Text = "Surprise Me!"
        Me.btnSurpriseMe.UseVisualStyleBackColor = True
        '
        'btnFinish
        '
        Me.btnFinish.Location = New System.Drawing.Point(901, 12)
        Me.btnFinish.Name = "btnFinish"
        Me.btnFinish.Size = New System.Drawing.Size(138, 80)
        Me.btnFinish.TabIndex = 3
        Me.btnFinish.Text = "Cross Game from Backlog"
        Me.btnFinish.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(901, 335)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(138, 80)
        Me.btnAdd.TabIndex = 4
        Me.btnAdd.Text = "Start Playing Selected Game"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'frmBacklog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1063, 451)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnFinish)
        Me.Controls.Add(Me.btnSurpriseMe)
        Me.Controls.Add(Me.dgvBacklog)
        Me.Name = "frmBacklog"
        Me.Text = "Backlog"
        CType(Me.dgvBacklog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VBacklogBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbLibraryManagerDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvBacklog As DataGridView
    Friend WithEvents DbLibraryManagerDataSet1 As dbLibraryManagerDataSet1
    Friend WithEvents VBacklogBindingSource As BindingSource
    Friend WithEvents VBacklogTableAdapter As dbLibraryManagerDataSet1TableAdapters.vBacklogTableAdapter
    Friend WithEvents btnSurpriseMe As Button
    Friend WithEvents btnFinish As Button
    Friend WithEvents IntGameIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrConsoleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrFormatDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrGenreDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StrLengthDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DtmDateAddedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnAdd As Button
End Class
