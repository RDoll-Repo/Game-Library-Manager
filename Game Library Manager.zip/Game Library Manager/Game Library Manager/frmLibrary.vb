﻿

Public Class frmLibrary
    Private Sub frmLibrary_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbLibraryManagerDataSet.vLibrary' table. You can move, or remove it, as needed.
        Me.VLibraryTableAdapter.Fill(Me.DbLibraryManagerDataSet.vLibrary)
    End Sub
End Class