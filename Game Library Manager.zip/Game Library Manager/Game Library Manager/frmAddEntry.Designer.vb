﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAddEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radPhysical = New System.Windows.Forms.RadioButton()
        Me.radDigital = New System.Windows.Forms.RadioButton()
        Me.grbFormat = New System.Windows.Forms.GroupBox()
        Me.btnAddEntry = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.radUnfinished = New System.Windows.Forms.RadioButton()
        Me.radPlaying = New System.Windows.Forms.RadioButton()
        Me.radFinished = New System.Windows.Forms.RadioButton()
        Me.grbStatus = New System.Windows.Forms.GroupBox()
        Me.radVeryShort = New System.Windows.Forms.RadioButton()
        Me.radShort = New System.Windows.Forms.RadioButton()
        Me.radMedium = New System.Windows.Forms.RadioButton()
        Me.radLong = New System.Windows.Forms.RadioButton()
        Me.radVeryLong = New System.Windows.Forms.RadioButton()
        Me.grbLength = New System.Windows.Forms.GroupBox()
        Me.cboConsole = New System.Windows.Forms.ComboBox()
        Me.cboGenre = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.grbFormat.SuspendLayout()
        Me.grbStatus.SuspendLayout()
        Me.grbLength.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(46, 44)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(272, 20)
        Me.txtTitle.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(158, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Title:"
        '
        'radPhysical
        '
        Me.radPhysical.AutoSize = True
        Me.radPhysical.Checked = True
        Me.radPhysical.Location = New System.Drawing.Point(25, 29)
        Me.radPhysical.Name = "radPhysical"
        Me.radPhysical.Size = New System.Drawing.Size(64, 17)
        Me.radPhysical.TabIndex = 11
        Me.radPhysical.TabStop = True
        Me.radPhysical.Text = "Physical"
        Me.radPhysical.UseVisualStyleBackColor = True
        '
        'radDigital
        '
        Me.radDigital.AutoSize = True
        Me.radDigital.Location = New System.Drawing.Point(25, 61)
        Me.radDigital.Name = "radDigital"
        Me.radDigital.Size = New System.Drawing.Size(54, 17)
        Me.radDigital.TabIndex = 12
        Me.radDigital.Text = "Digital"
        Me.radDigital.UseVisualStyleBackColor = True
        '
        'grbFormat
        '
        Me.grbFormat.Controls.Add(Me.radPhysical)
        Me.grbFormat.Controls.Add(Me.radDigital)
        Me.grbFormat.Location = New System.Drawing.Point(45, 224)
        Me.grbFormat.Name = "grbFormat"
        Me.grbFormat.Size = New System.Drawing.Size(122, 89)
        Me.grbFormat.TabIndex = 13
        Me.grbFormat.TabStop = False
        Me.grbFormat.Text = "Format:"
        '
        'btnAddEntry
        '
        Me.btnAddEntry.Location = New System.Drawing.Point(81, 331)
        Me.btnAddEntry.Name = "btnAddEntry"
        Me.btnAddEntry.Size = New System.Drawing.Size(75, 46)
        Me.btnAddEntry.TabIndex = 18
        Me.btnAddEntry.Text = "Add Entry"
        Me.btnAddEntry.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(197, 331)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 46)
        Me.btnClose.TabIndex = 19
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'radUnfinished
        '
        Me.radUnfinished.AutoSize = True
        Me.radUnfinished.Checked = True
        Me.radUnfinished.Location = New System.Drawing.Point(25, 32)
        Me.radUnfinished.Name = "radUnfinished"
        Me.radUnfinished.Size = New System.Drawing.Size(75, 17)
        Me.radUnfinished.TabIndex = 20
        Me.radUnfinished.TabStop = True
        Me.radUnfinished.Text = "Unfinished"
        Me.radUnfinished.UseVisualStyleBackColor = True
        '
        'radPlaying
        '
        Me.radPlaying.AutoSize = True
        Me.radPlaying.Location = New System.Drawing.Point(25, 57)
        Me.radPlaying.Name = "radPlaying"
        Me.radPlaying.Size = New System.Drawing.Size(59, 17)
        Me.radPlaying.TabIndex = 21
        Me.radPlaying.Text = "Playing"
        Me.radPlaying.UseVisualStyleBackColor = True
        '
        'radFinished
        '
        Me.radFinished.AutoSize = True
        Me.radFinished.Location = New System.Drawing.Point(25, 82)
        Me.radFinished.Name = "radFinished"
        Me.radFinished.Size = New System.Drawing.Size(64, 17)
        Me.radFinished.TabIndex = 22
        Me.radFinished.Text = "Finished"
        Me.radFinished.UseVisualStyleBackColor = True
        '
        'grbStatus
        '
        Me.grbStatus.Controls.Add(Me.radUnfinished)
        Me.grbStatus.Controls.Add(Me.radFinished)
        Me.grbStatus.Controls.Add(Me.radPlaying)
        Me.grbStatus.Location = New System.Drawing.Point(45, 85)
        Me.grbStatus.Name = "grbStatus"
        Me.grbStatus.Size = New System.Drawing.Size(122, 124)
        Me.grbStatus.TabIndex = 23
        Me.grbStatus.TabStop = False
        Me.grbStatus.Text = "Status:"
        '
        'radVeryShort
        '
        Me.radVeryShort.AutoSize = True
        Me.radVeryShort.Checked = True
        Me.radVeryShort.Location = New System.Drawing.Point(6, 22)
        Me.radVeryShort.Name = "radVeryShort"
        Me.radVeryShort.Size = New System.Drawing.Size(104, 17)
        Me.radVeryShort.TabIndex = 24
        Me.radVeryShort.TabStop = True
        Me.radVeryShort.Text = "Very Short ( >10)"
        Me.radVeryShort.UseVisualStyleBackColor = True
        '
        'radShort
        '
        Me.radShort.AutoSize = True
        Me.radShort.Location = New System.Drawing.Point(6, 45)
        Me.radShort.Name = "radShort"
        Me.radShort.Size = New System.Drawing.Size(86, 17)
        Me.radShort.TabIndex = 25
        Me.radShort.Text = "Short (10-20)"
        Me.radShort.UseVisualStyleBackColor = True
        '
        'radMedium
        '
        Me.radMedium.AutoSize = True
        Me.radMedium.Location = New System.Drawing.Point(6, 68)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(98, 17)
        Me.radMedium.TabIndex = 26
        Me.radMedium.Text = "Medium (20-30)"
        Me.radMedium.UseVisualStyleBackColor = True
        '
        'radLong
        '
        Me.radLong.AutoSize = True
        Me.radLong.Location = New System.Drawing.Point(6, 91)
        Me.radLong.Name = "radLong"
        Me.radLong.Size = New System.Drawing.Size(85, 17)
        Me.radLong.TabIndex = 27
        Me.radLong.Text = "Long (30-40)"
        Me.radLong.UseVisualStyleBackColor = True
        '
        'radVeryLong
        '
        Me.radVeryLong.AutoSize = True
        Me.radVeryLong.Location = New System.Drawing.Point(6, 114)
        Me.radVeryLong.Name = "radVeryLong"
        Me.radVeryLong.Size = New System.Drawing.Size(100, 17)
        Me.radVeryLong.TabIndex = 28
        Me.radVeryLong.Text = "Very Long (40+)"
        Me.radVeryLong.UseVisualStyleBackColor = True
        '
        'grbLength
        '
        Me.grbLength.Controls.Add(Me.radVeryShort)
        Me.grbLength.Controls.Add(Me.radVeryLong)
        Me.grbLength.Controls.Add(Me.radShort)
        Me.grbLength.Controls.Add(Me.radLong)
        Me.grbLength.Controls.Add(Me.radMedium)
        Me.grbLength.Location = New System.Drawing.Point(197, 170)
        Me.grbLength.Name = "grbLength"
        Me.grbLength.Size = New System.Drawing.Size(121, 143)
        Me.grbLength.TabIndex = 29
        Me.grbLength.TabStop = False
        Me.grbLength.Text = "Length (In Hours)"
        '
        'cboConsole
        '
        Me.cboConsole.FormattingEnabled = True
        Me.cboConsole.Location = New System.Drawing.Point(197, 94)
        Me.cboConsole.Name = "cboConsole"
        Me.cboConsole.Size = New System.Drawing.Size(121, 21)
        Me.cboConsole.TabIndex = 30
        Me.cboConsole.Text = "Console"
        '
        'cboGenre
        '
        Me.cboGenre.FormattingEnabled = True
        Me.cboGenre.Location = New System.Drawing.Point(197, 138)
        Me.cboGenre.Name = "cboGenre"
        Me.cboGenre.Size = New System.Drawing.Size(121, 21)
        Me.cboGenre.TabIndex = 31
        Me.cboGenre.Text = "Genre"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(194, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Console:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(194, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Genre:"
        '
        'frmAddEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(357, 413)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cboGenre)
        Me.Controls.Add(Me.cboConsole)
        Me.Controls.Add(Me.grbLength)
        Me.Controls.Add(Me.grbStatus)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddEntry)
        Me.Controls.Add(Me.grbFormat)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTitle)
        Me.Name = "frmAddEntry"
        Me.Text = "Add Game"
        Me.grbFormat.ResumeLayout(False)
        Me.grbFormat.PerformLayout()
        Me.grbStatus.ResumeLayout(False)
        Me.grbStatus.PerformLayout()
        Me.grbLength.ResumeLayout(False)
        Me.grbLength.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtTitle As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents radPhysical As RadioButton
    Friend WithEvents radDigital As RadioButton
    Friend WithEvents grbFormat As GroupBox
    Friend WithEvents btnAddEntry As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents radUnfinished As RadioButton
    Friend WithEvents radPlaying As RadioButton
    Friend WithEvents radFinished As RadioButton
    Friend WithEvents grbStatus As GroupBox
    Friend WithEvents radVeryShort As RadioButton
    Friend WithEvents radShort As RadioButton
    Friend WithEvents radMedium As RadioButton
    Friend WithEvents radLong As RadioButton
    Friend WithEvents radVeryLong As RadioButton
    Friend WithEvents grbLength As GroupBox
    Friend WithEvents cboConsole As ComboBox
    Friend WithEvents cboGenre As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
End Class
