﻿Public Class frmBacklog
    Private Sub frmBacklog_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbLibraryManagerDataSet.vLibrary' table. You can move, or remove it, as needed.
        Me.VBacklogTableAdapter.Fill(Me.DbLibraryManagerDataSet1.vBacklog)
    End Sub
    Private Sub btnSurpriseMe_Click(sender As Object, e As EventArgs) Handles btnSurpriseMe.Click
        Dim intSuggestion As Integer = Rnd(dgvBacklog.Rows.Count)

        Do Until dgvBacklog.Rows(intSuggestion).Cells.Item(2).Value.ToString = "Unfinished"
            intSuggestion = Rnd(dgvBacklog.Rows.Count)
        Loop
        Dim result As DialogResult

        result = MessageBox.Show("Do you want to play " & dgvBacklog.Rows(intSuggestion).Cells.Item(1).Value.ToString & " ?", "Add Game to Currently Playing?", MessageBoxButtons.YesNo)

        Select Case result
            Case DialogResult.No
                MessageBox.Show("Okay, let's try something else.")
            Case DialogResult.Yes
                Dim intID As Integer
                Dim intStatusID As Integer
                Dim dtmDateFinished As Nullable(Of Date)

                Try
                    intID = dgvBacklog.Rows(intSuggestion).Cells.Item(0).Value.ToString
                    intStatusID = 2
                    Dim cmdUpdateGame As New OleDb.OleDbCommand
                    Dim intRowsAffected As Integer

                    If OpenDatabaseConnectionSQLServer() = False Then
                        MessageBox.Show(Me, "Database connection error." & vbNewLine & "The application will now close.",
                    Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        Me.Close()
                    End If

                    cmdUpdateGame.CommandText = ("EXECUTE uspUpdateGameStatus '" & intID & "','" & intStatusID & "','" & dtmDateFinished & "'")
                    cmdUpdateGame.CommandType = CommandType.StoredProcedure
                    cmdUpdateGame = New OleDb.OleDbCommand(cmdUpdateGame.CommandText, m_conAdministrator)
                    intRowsAffected = cmdUpdateGame.ExecuteNonQuery

                    If intRowsAffected < 0 Then
                        MessageBox.Show("You got it, chief")
                        CloseDatabaseConnection()
                        Close()
                    End If

                    CloseDatabaseConnection()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
        End Select
    End Sub

    Private Sub btnFinish_Click(sender As Object, e As EventArgs) Handles btnFinish.Click
        Dim intID As Integer = dgvBacklog.CurrentRow.Cells.Item(0).Value.ToString
        Dim intStatusID As Integer
        Dim dtmDateFinished

        Try
            intStatusID = 3
            dtmDateFinished = Date.Now


            Dim cmdFinishGame As New OleDb.OleDbCommand
            Dim intRowsAffected As Integer

            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine & "The application will now close.",
            Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                Me.Close()
            End If

            cmdFinishGame.CommandText = ("EXECUTE uspFinishGame '" & intID & "','" & intStatusID & "','" & dtmDateFinished & "'")
            cmdFinishGame.CommandType = CommandType.StoredProcedure
            cmdFinishGame = New OleDb.OleDbCommand(cmdFinishGame.CommandText, m_conAdministrator)
            intRowsAffected = cmdFinishGame.ExecuteNonQuery

            If intRowsAffected < 0 Then
                MessageBox.Show("Hey, good job!")
                CloseDatabaseConnection()
                Close()
            End If

            CloseDatabaseConnection()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If dgvBacklog.CurrentRow.Cells.Item(2).Value.ToString = "Playing" Then
            MessageBox.Show("Looks like you're already playing this one!")
        Else
            Dim result As DialogResult

            result = MessageBox.Show("Do you want to play " & dgvBacklog.CurrentRow.Cells.Item(1).Value.ToString & " ?", "Add Game to Currently Playing?", MessageBoxButtons.YesNo)

            Select Case result
                Case DialogResult.No
                    MessageBox.Show("Okay, let's try something else.")
                Case DialogResult.Yes
                    Dim intID As Integer
                    Dim intStatusID As Integer
                    Dim dtmDateFinished As Nullable(Of Date)

                    Try
                        intID = dgvBacklog.CurrentRow.Cells.Item(0).Value.ToString
                        intStatusID = 2
                        Dim cmdUpdateGame As New OleDb.OleDbCommand
                        Dim intRowsAffected As Integer

                        If OpenDatabaseConnectionSQLServer() = False Then
                            MessageBox.Show(Me, "Database connection error." & vbNewLine & "The application will now close.",
                        Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            Me.Close()
                        End If

                        cmdUpdateGame.CommandText = ("EXECUTE uspUpdateGameStatus '" & intID & "','" & intStatusID & "','" & dtmDateFinished & "'")
                        cmdUpdateGame.CommandType = CommandType.StoredProcedure
                        cmdUpdateGame = New OleDb.OleDbCommand(cmdUpdateGame.CommandText, m_conAdministrator)
                        intRowsAffected = cmdUpdateGame.ExecuteNonQuery

                        If intRowsAffected < 0 Then
                            MessageBox.Show("You got it, chief")
                            CloseDatabaseConnection()
                            Close()
                        End If

                        CloseDatabaseConnection()
                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    End Try
            End Select
        End If
    End Sub
End Class