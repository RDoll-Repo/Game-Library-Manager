﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddEntry = New System.Windows.Forms.Button()
        Me.pgrProgress = New System.Windows.Forms.ProgressBar()
        Me.btnLibrary = New System.Windows.Forms.Button()
        Me.btnBacklog = New System.Windows.Forms.Button()
        Me.lblProgress = New System.Windows.Forms.Label()
        Me.lstCurrentlyPlaying = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnAddEntry
        '
        Me.btnAddEntry.Location = New System.Drawing.Point(505, 139)
        Me.btnAddEntry.Name = "btnAddEntry"
        Me.btnAddEntry.Size = New System.Drawing.Size(93, 70)
        Me.btnAddEntry.TabIndex = 1
        Me.btnAddEntry.Text = "Add Entry"
        Me.btnAddEntry.UseVisualStyleBackColor = True
        '
        'pgrProgress
        '
        Me.pgrProgress.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.pgrProgress.Location = New System.Drawing.Point(272, 49)
        Me.pgrProgress.Name = "pgrProgress"
        Me.pgrProgress.Size = New System.Drawing.Size(326, 58)
        Me.pgrProgress.TabIndex = 4
        '
        'btnLibrary
        '
        Me.btnLibrary.Location = New System.Drawing.Point(272, 139)
        Me.btnLibrary.Name = "btnLibrary"
        Me.btnLibrary.Size = New System.Drawing.Size(93, 70)
        Me.btnLibrary.TabIndex = 5
        Me.btnLibrary.Text = "View Library"
        Me.btnLibrary.UseVisualStyleBackColor = True
        '
        'btnBacklog
        '
        Me.btnBacklog.Location = New System.Drawing.Point(392, 139)
        Me.btnBacklog.Name = "btnBacklog"
        Me.btnBacklog.Size = New System.Drawing.Size(93, 70)
        Me.btnBacklog.TabIndex = 6
        Me.btnBacklog.Text = "View Backlog"
        Me.btnBacklog.UseVisualStyleBackColor = True
        '
        'lblProgress
        '
        Me.lblProgress.AutoSize = True
        Me.lblProgress.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgress.Location = New System.Drawing.Point(346, 21)
        Me.lblProgress.Name = "lblProgress"
        Me.lblProgress.Size = New System.Drawing.Size(113, 25)
        Me.lblProgress.TabIndex = 7
        Me.lblProgress.Text = "Progress:"
        '
        'lstCurrentlyPlaying
        '
        Me.lstCurrentlyPlaying.FormattingEnabled = True
        Me.lstCurrentlyPlaying.Location = New System.Drawing.Point(26, 49)
        Me.lstCurrentlyPlaying.Name = "lstCurrentlyPlaying"
        Me.lstCurrentlyPlaying.Size = New System.Drawing.Size(195, 160)
        Me.lstCurrentlyPlaying.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(80, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Currently Playing:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(620, 223)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstCurrentlyPlaying)
        Me.Controls.Add(Me.lblProgress)
        Me.Controls.Add(Me.btnBacklog)
        Me.Controls.Add(Me.btnLibrary)
        Me.Controls.Add(Me.pgrProgress)
        Me.Controls.Add(Me.btnAddEntry)
        Me.Name = "frmMain"
        Me.Text = "Game Library Manager"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAddEntry As Button
    Friend WithEvents pgrProgress As ProgressBar
    Friend WithEvents btnLibrary As Button
    Friend WithEvents btnBacklog As Button
    Friend WithEvents lblProgress As Label
    Friend WithEvents lstCurrentlyPlaying As ListBox
    Friend WithEvents Label1 As Label
End Class
