﻿Public Class frmMain

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Progress_Load()
            Load_CurrentlyPlaying()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnAddEntry_Click(sender As Object, e As EventArgs) Handles btnAddEntry.Click
        Dim frmAddEntry As New frmAddEntry
        frmAddEntry.ShowDialog()
        frmMain_Load(sender, e)
    End Sub

    Private Sub Progress_Load()
        Try

            Dim intCurrentPoints As Integer
            Dim intTotalPoints As Integer

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader
            Dim dt As DataTable = New DataTable

            'Making sure the DB can be reached
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If

            'building select statement
            strSelect = "SELECT CurrentPoints from vCurrentPoints"

            'Retrieving Records
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loading table
            dt.Load(drSourceTable)
            intCurrentPoints = cmdSelect.ExecuteScalar

            strSelect = "SELECT TotalPoints from vTotalPoints"

            'Retrieving Records
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loading table
            dt.Load(drSourceTable)
            intTotalPoints = cmdSelect.ExecuteScalar

            pgrProgress.ForeColor = Color.Purple
            pgrProgress.Value = (intCurrentPoints / intTotalPoints) * 100
            lblProgress.Text = "Progress: " & pgrProgress.Value & "%"

            'ending update and cleaning up
            drSourceTable.Close()
            CloseDatabaseConnection()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Load_CurrentlyPlaying()
        Try
            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader
            Dim dt As DataTable = New DataTable

            'Making sure the DB can be reached
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If

            'show all changes
            lstCurrentlyPlaying.BeginUpdate()

            'building select statement
            strSelect = "SELECT intGameID, strName from vCurrentlyPlaying"

            'retrieve records and load table
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dt.Load(drSourceTable)

            'populating listbox
            lstCurrentlyPlaying.ValueMember = "intGameID"
            lstCurrentlyPlaying.DisplayMember = "strName"
            lstCurrentlyPlaying.DataSource = dt

            'showing changes and cleaning
            lstCurrentlyPlaying.EndUpdate()
            drSourceTable.Close()
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnLibrary_Click(sender As Object, e As EventArgs) Handles btnLibrary.Click
        Dim frmLibrary As New frmLibrary
        frmLibrary.ShowDialog()
    End Sub

    Private Sub btnBacklog_Click(sender As Object, e As EventArgs) Handles btnBacklog.Click
        Dim frmBacklog As New frmBacklog
        frmBacklog.ShowDialog()
        frmMain_Load(sender, e)
    End Sub
End Class
