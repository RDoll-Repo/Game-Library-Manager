﻿Option Strict On

Public Class frmAddEntry
    Private Sub frmAddEntry_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Load_Consoles()
        Load_Genres()
    End Sub

    Private Sub Load_Consoles()
        Try
            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader
            Dim dt As DataTable = New DataTable

            'Making sure the DB can be reached
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If

            'showing all changes
            cboConsole.BeginUpdate()

            'building select statement
            strSelect = "SELECT intConsoleID, strConsole FROM TConsole"

            'Retrieving Records
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loading table
            dt.Load(drSourceTable)

            'Loading combobox for events and loading the first item by default
            cboConsole.ValueMember = "intConsoleID"
            cboConsole.DisplayMember = "strConsole"
            cboConsole.DataSource = dt


            'ending update and cleaning up
            cboConsole.EndUpdate()
            drSourceTable.Close()
            CloseDatabaseConnection()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Load_Genres()
        Try
            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader
            Dim dt As DataTable = New DataTable

            'Making sure the DB can be reached
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If

            'showing all changes
            cboGenre.BeginUpdate()

            'building select statement
            strSelect = "SELECT intGenreID, strGenre FROM TGenre"

            'Retrieving Records
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loading table
            dt.Load(drSourceTable)

            'Loading combobox for events and loading the first item by default
            cboGenre.ValueMember = "intGenreID"
            cboGenre.DisplayMember = "strGenre"
            cboGenre.DataSource = dt

            'ending update and cleaning up
            cboGenre.EndUpdate()
            drSourceTable.Close()
            CloseDatabaseConnection()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Function Validation() As Boolean
        If txtTitle.Text = "" Then
            MessageBox.Show("Please Enter a Title")
            txtTitle.BackColor = Color.Yellow
            txtTitle.Focus()
            Return False
        End If

        Return True
    End Function

    Private Sub btnAddEntry_Click(sender As Object, e As EventArgs) Handles btnAddEntry.Click
        txtTitle.BackColor = Color.White
        If Validation() = True Then
            Dim strName As String = ""
            Dim intStatusID As Integer
            Dim intConsoleID As Integer
            Dim intFormatID As Integer
            Dim intGenreID As Integer
            Dim intLengthID As Integer
            Dim dtmDateAdded As Date
            Dim dtmDateFinished As Nullable(Of Date)

            Try
                strName = txtTitle.Text
                CheckStatus(intStatusID)
                intConsoleID = CInt(cboConsole.SelectedValue)
                CheckFormat(intFormatID)
                intGenreID = CInt(cboGenre.SelectedValue)
                CheckLength(intLengthID)
                dtmDateAdded = Date.Now
                If intStatusID = 3 Then
                    dtmDateFinished = Date.Now
                End If

                Dim cmdAddGame As New OleDb.OleDbCommand
                Dim intRowsAffected As Integer
                Dim intPKID As Integer

                If OpenDatabaseConnectionSQLServer() = False Then
                    MessageBox.Show(Me, "Database connection error." & vbNewLine & "The application will now close.",
                Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                    Me.Close()
                End If

                cmdAddGame.CommandText = ("EXECUTE uspAddGame '" & intPKID & "','" & strName & "','" & intStatusID & "','" & intConsoleID & "','" & intFormatID &
                    "','" & intGenreID & "','" & intLengthID & "','" & dtmDateAdded & "','" & dtmDateFinished & "'")
                cmdAddGame.CommandType = CommandType.StoredProcedure
                cmdAddGame = New OleDb.OleDbCommand(cmdAddGame.CommandText, m_conAdministrator)
                intRowsAffected = cmdAddGame.ExecuteNonQuery

                If intRowsAffected < 0 Then
                    MessageBox.Show("Game successfully added")
                    CloseDatabaseConnection()
                    Close()
                End If

                CloseDatabaseConnection()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If
    End Sub

    Public Function CheckStatus(ByRef intStatusID As Integer) As Integer
        Select Case True
            Case radUnfinished.Checked
                intStatusID = 1
            Case radPlaying.Checked
                intStatusID = 2
            Case radFinished.Checked
                intStatusID = 3
        End Select
        Return intStatusID
    End Function

    Public Function CheckFormat(ByRef intFormatID As Integer) As Integer
        Select Case True
            Case radPhysical.Checked
                intFormatID = 1
            Case radDigital.Checked
                intFormatID = 2
        End Select
        Return intFormatID
    End Function

    Public Function CheckLength(ByRef intLengthID As Integer) As Integer
        Select Case True
            Case radVeryShort.Checked
                intLengthID = 1
            Case radShort.Checked
                intLengthID = 2
            Case radMedium.Checked
                intLengthID = 3
            Case radLong.Checked
                intLengthID = 4
            Case radVeryLong.Checked
                intLengthID = 5
        End Select
        Return intLengthID
    End Function
End Class