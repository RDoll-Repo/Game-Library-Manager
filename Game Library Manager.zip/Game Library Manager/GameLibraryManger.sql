-- --------------------------------------------------------------------------------
-- Name: Roland Doll
-- Class: Extracuricular
-- Abstract: Game Library Manager
-- --------------------------------------------------------------------------------

-- --------------------------------------------------------------------------------
-- Option
-- --------------------------------------------------------------------------------
USE dbLibraryManager
SET NOCOUNT ON;

-- --------------------------------------------------------------------------------
-- Drop table/view statements
-- --------------------------------------------------------------------------------
IF OBJECT_ID('TGame')					IS NOT NULL DROP TABLE TGame
IF OBJECT_ID('TConsole')				IS NOT NULL DROP TABLE TConsole
IF OBJECT_ID('TLength')					IS NOT NULL DROP TABLE TLength
IF OBJECT_ID('TStatus')					IS NOT NULL DROP TABLE TStatus
IF OBJECT_ID('TGenre')					IS NOT NULL DROP TABLE TGenre
IF OBJECT_ID('TFormat')					IS NOT NULL DROP TABLE TFormat

IF OBJECT_ID('vLibrary')				IS NOT NULL DROP VIEW  vLibrary
IF OBJECT_ID('vBacklog')				IS NOT NULL DROP VIEW  vBacklog
IF OBJECT_ID('vTotalPoints')			IS NOT NULL DROP VIEW  vTotalPoints
IF OBJECT_ID('vCurrentPoints')			IS NOT NULL DROP VIEW  vCurrentPoints
-- --------------------------------------------------------------------------------
-- Step #1.1: Create Tables
-- --------------------------------------------------------------------------------
CREATE TABLE TGenre
(
	 intGenreID			INTEGER				NOT NULL
	,strGenre			VARCHAR(255)		NOT NULL
	,CONSTRAINT TGenre_PK PRIMARY KEY (intGenreID)
)


CREATE TABLE TStatus
(
	 intStatusID		INTEGER				NOT NULL
	,strStatus			VARCHAR(255)		NOT NULL
	,CONSTRAINT TStatus_PK PRIMARY KEY (intStatusID)
)


CREATE TABLE TLength
(
	 intLengthID		INTEGER				NOT NULL
	,strLength			VARCHAR(255)		NOT NULL
	,CONSTRAINT TLength_PK PRIMARY KEY (intLengthID)
)


CREATE TABLE TConsole
(
	 intConsoleID		INTEGER			NOT NULL
	,strConsole			VARCHAR(100)	NOT NULL
	,CONSTRAINT TConsole_PK PRIMARY KEY (intConsoleID)
)


CREATE TABLE TFormat
(
	 intFormatID		INTEGER			NOT NULL
	,strFormat			VARCHAR(50)		NOT NULL
	,CONSTRAINT TFormat_PK PRIMARY KEY (intFormatID)
)


CREATE TABLE TGame
(
	 intGameID			INTEGER			NOT NULL
	,strName			VARCHAR(255)	NOT NULL
	,intStatusID		INTEGER			NOT NULL
	,intConsoleID		INTEGER			NOT NULL
	,intFormatID		INTEGER			NOT NULL
	,intGenreID			INTEGER			NOT NULL
	,intLengthID		INTEGER			NOT NULL
	,dtmDateAdded		DATE			NOT NULL
	,dtmDateFinished	DATE			NULL
	,CONSTRAINT TGame_PK PRIMARY KEY (intGameID)
)


-- --------------------------------------------------------------------------------
-- Step #1.2: Foreign Keys
-- --------------------------------------------------------------------------------

--		Child					Parent				Column(s)
--		-----					------				---------
--	1	TGame					TGenre				intGenreID
--	2	TGame					TStatus				intStatusID
--  3	TGame					TLength				intLengthID
--  4   TGame					TConsole			intConsoleID
--  5   TGame					TFormat				intFormatID

-- 1
ALTER TABLE TGame ADD CONSTRAINT TGame_TGenre_FK
FOREIGN KEY (intGenreID) REFERENCES TGenre(intGenreID)

-- 2
ALTER TABLE TGame ADD CONSTRAINT TGame_TStatus_FK
FOREIGN KEY (intStatusID) REFERENCES TStatus(intStatusID)

-- 3
ALTER TABLE TGame ADD CONSTRAINT TGame_TLength_FK
FOREIGN KEY (intLengthID) REFERENCES TLength(intLengthID)

-- 4
ALTER TABLE TGame ADD CONSTRAINT TGame_TConsole_FK
FOREIGN KEY (intConsoleID) REFERENCES TConsole(intConsoleID)

-- 5
ALTER TABLE TGame ADD CONSTRAINT TGame_TFormat_FK
FOREIGN KEY (intFormatID) REFERENCES TFormat(intFormatID)

-- --------------------------------------------------------------------------------
-- Step #3-1: Genres
-- --------------------------------------------------------------------------------

INSERT INTO TGenre (intGenreID, strGenre)
VALUES   (1, 'Action-Adventure')
		,(2, 'Action-RPG')
		,(3, 'Arcade')
		,(4, 'Beat-em Up')
		,(5, 'Card Battle')
		,(6, 'Character-Action')
		,(7, 'Cinematic Platformer')
		,(8, 'Collectathon')
		,(9, 'Compilation')
		,(10, 'Dungeon Crawler')
		,(11, 'Fighter')
		,(12, 'First-Person Shooter')
		,(13, 'Hack and Slash')
		,(14, 'Isometric RPG')
		,(15, 'Japanese RPG')
		,(16, 'Metroidvania')
		,(17, 'MMO')
		,(18,'Musuo')
		,(19, 'Open-World/Sandbox')
		,(20, 'Party')
		,(21, 'Platformer')
		,(22, 'Puzzle')
		,(23, 'Racing')
		,(24, 'Rage Game')
		,(25, 'Rail Shooter')
		,(26, 'Real-Time Strategy')
		,(27, 'Rhythm')
		,(28, 'Roguelike')
		,(29, 'Shoot-em Up')
		,(30, 'Side-Scroller')
		,(31, 'Simulation')
		,(32, 'Soulslike')
		,(33, 'Sports')
		,(34, 'Stealth')
		,(35, 'Survival')
		,(36, 'Survival Horror')
		,(37, 'Tactical RPG')
		,(38, 'Visual Novel')
		,(39, 'Western RPG')

-- --------------------------------------------------------------------------------
-- Step #3-2: Status
-- --------------------------------------------------------------------------------
INSERT INTO TStatus(intStatusID, strStatus)
VALUES	 (1, 'Unfinished')
		,(2, 'Playing')
		,(3, 'Finished')

-- --------------------------------------------------------------------------------
-- Step #3-3: Length
-- --------------------------------------------------------------------------------
INSERT INTO TLength(intLengthID, strLength)
VALUES	 (1, 'Very Short')
		,(2, 'Short')
		,(3, 'Medium')
		,(4, 'Long')
		,(5, 'Very Long')

-- --------------------------------------------------------------------------------
-- Step #3-4: Console
-- --------------------------------------------------------------------------------
INSERT INTO TConsole(intConsoleID, strConsole)
VALUES	 (1, 'NES')
		,(2, 'SNES')
		,(3, 'Nintendo 64')
		,(4, 'GameCube')
		,(5, 'Wii')
		,(6, 'Wii U')
		,(7, 'Nintendo Switch')
		,(8, 'Gameboy/Color')
		,(9, 'Gameboy Advance')
		,(10, 'Nintendo DS')
		,(11, 'Nintendo 3DS')
		,(12, 'Sega Master System')
		,(13, 'Sega Genesis')
		,(14, 'Sega Saturn')
		,(15, 'Sega Dreamcast')
		,(16, 'Playstation')
		,(17, 'Playstation 2')
		,(18, 'Playstation 3')
		,(19, 'Playstation 4')
		,(20, 'Playstation 5')
		,(21, 'Playstation Portable')
		,(22, 'Playstation Vita')
		,(23, 'Xbox')
		,(24, 'Xbox 360')
		,(25, 'Xbox One')
		,(26, 'Xbox Series X/S')
		,(27, 'PC')
		,(28, 'Other')

-- --------------------------------------------------------------------------------
-- Step #3-5: Format
-- --------------------------------------------------------------------------------
INSERT INTO TFormat(intFormatID, strFormat)
VALUES	 (1, 'Physical')
		,(2, 'Digital')

-- --------------------------------------------------------------------------------
-- Step #4: Games (For Testing)
-- --------------------------------------------------------------------------------
INSERT INTO TGame(intGameID,strName,intStatusID,intConsoleID,intFormatID,intGenreID	,intLengthID,dtmDateAdded,dtmDateFinished)
VALUES	 (1, 'Trails of Cold Steel II', 3, 19, 1, 15, 5, '12/14/20', '12/14/20')
		,(2, 'Xenoblade Chronicles X', 1, 6, 1, 15, 5, '12/14/20', NULL)
		,(3, 'Ys I & II Chronicles', 2, 21, 1, 15, 2, '12/14/20', NULL)


-- --------------------------------------------------------------------------------
-- Step #5: Testing
-- --------------------------------------------------------------------------------
GO

CREATE VIEW vLibrary
AS
SELECT
	 TG.intGameID
	,TG.strName
	,TS.strStatus
	,TC.strConsole
	,TF.strFormat
	,TGe.strGenre
	,TL.strLength
	,TG.dtmDateAdded
	,TG.dtmDateFinished
FROM
	TGame as TG
		JOIN TStatus as TS
		ON TS.intStatusID = TG.intStatusID
			JOIN TConsole as TC
			ON TC.intConsoleID = TG.intConsoleID
				JOIN TFormat as TF
				ON TF.intFormatID = TG.intFormatID
					JOIN TGenre as TGe
					ON TGe.intGenreID = TG.intGenreID
						JOIN TLength as TL
						ON TL.intLengthID = TG.intLengthID

GO

SELECT * FROM vLibrary

GO


GO

CREATE VIEW vBacklog
AS
SELECT
	 TG.intGameID
	,TG.strName
	,TS.strStatus 
	,TC.strConsole 
	,TF.strFormat 
	,TGe.strGenre 
	,TL.strLength 
	,TG.dtmDateAdded 
	,TG.dtmDateFinished 
FROM
	TGame as TG
		JOIN TStatus as TS
		ON TS.intStatusID = TG.intStatusID
			JOIN TConsole as TC
			ON TC.intConsoleID = TG.intConsoleID
				JOIN TFormat as TF
				ON TF.intFormatID = TG.intFormatID
					JOIN TGenre as TGe
					ON TGe.intGenreID = TG.intGenreID
						JOIN TLength as TL
						ON TL.intLengthID = TG.intLengthID

WHERE TG.intStatusID <> 3

GO

SELECT * FROM vBacklog

GO


GO

CREATE VIEW vTotalPoints
AS 
SELECT
	 SUM(intLengthID) as 'Total Points'
FROM 
	TGame

GO

SELECT * FROM vTotalPoints


GO

CREATE VIEW vCurrentPoints
AS 
SELECT
	 SUM(intLengthID) as 'Current Points'

FROM 
	TGame

WHERE
	intStatusID = 3
GO

SELECT * FROM vCurrentPoints